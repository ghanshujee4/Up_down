$(document).ready(function()
			{                                  
				var disabledDays = ["2014-12-12","2014-12-23","2014-12-27"];
                $('#datepicker').datepicker({
	                dateFormat: 'yy-mm-dd',
                    beforeShowDay: function(date) {
						var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
						for (i = 0; i < disabledDays.length; i++) {
							if($.inArray(y + '-' + (m+1) + '-' + d,disabledDays) != -1) {
								return [true, 'Highlighted'];
							}
						}
						return [true];
					},
		            onChangeMonthYear: function () {
					} 
					});                 
   
                setInterval(function() {
                 
						$(".Highlighted .ui-state-default").click(function() {
						
						
						if ($(this).text() == 17)
						{	
						
							$('#datedialog1').show();
							$('#selected_date').text('17th Nov');
							$('#dateinfo').text('EMI due on the loan:  605 GBP');
													
						}
						if ($(this).text() == 22)
						{							
							$('#datedialog1').show();
							$('#selected_date').text('22nd Nov');
							$('#dateinfo').text('Home Insurance Premium 1234564567 is due');					
						}
						
						if ($(this).text() == 24)
						{							
							$('#datedialog1').show();
							$('#selected_date').text('24th Nov');
							$('#dateinfo').text('WeBSaveR ISA 2 A/C 88900121928 interest payout Date');							
																	
						}
						if ($(this).text() == 21)
						{							
							$('#datedialog1').show();
							$('#selected_date').text('21th Nov');
							$('#dateinfo').text('Scheduled Redemption of WeBSaveR 2 A/C	888723675298');							
																	
						}						
                                                                
						});
						$(".Highlighted .ui-state-default").mouseout(function() {
							$('#datedialog1').hide();
						});
                }, 200);
                  
			});

		function showAccountLookUp()
		{
			$("#accountLookUpmodal").modal();
		}	

		function showCustLookUp(){
			$("#custLookUpmodal").modal();
		}

		

		function showAccountDetails()
		{
			window.location.href='AccountLookup.html';
		}

		function showCustDetails()
		{		
			window.location.href='CustomerLookup.html';	
		}


		//Script call on page load
		$(document).ready(function()
			{  
				$("#divMortgage").hide();	

				$("#divMDateE").hide();	
				$("#divMAccE").hide();	
				$("#divMSortE").hide();	
				$("#divMDate").show();	
				$("#divMAcc").show();	
				$("#divMSort").show();

				$("#btnSave").hide();	
				$("#btnEdit").show();

				$("#sucessmsg").hide();
			});	

			function showMortgages(){
				$('#divMortgage').show();
				$('#accountview').addClass("no-margin-bt")
			}

			function showMortgageDebit(){
				$("#mortgageDebit").modal();

				$("#divMDateE").hide();	
				$("#divMAccE").hide();	
				$("#divMSortE").hide();	
				$("#divMDate").show();	
				$("#divMAcc").show();	
				$("#divMSort").show();

				$("#btnSave").hide();	
				$("#btnEdit").show();
			}

			function showMortgageEdit(){
				$("#divMDateE").show();	
				$("#divMAccE").show();	
				$("#divMSortE").show();	
				
				$("#divMDate").hide();	
				$("#divMAcc").hide();	
				$("#divMSort").hide();

				$("#btnSave").show();
				$("#btnEdit").hide();
			}

			function sucessMessage(){
				$("#sucessmsg").show();
			}

