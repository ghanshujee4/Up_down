
$(function(){
	
	jsKeyboard.init("virtualKeyboard");

	//first input focus

	var $firstInput = $(':input.text').first().focus();
	jsKeyboard.currentElement = $firstInput;
	jsKeyboard.currentElementCursorPosition = 0;


	// keyboard

	$('.enablevirtualkeyboard .chkbox').click(function() {

	  var clicks = $(this).data('clicks');
	  
	  if (clicks) {
	  	$(this).removeClass('cliked');
	  	$('.row.registerwidget').show();
	  	$('.row.keyboard').hide();
	  } 

	  else {
	  	$(this).addClass('cliked');
	  	$('.row.registerwidget').hide();
	  	$('.row.keyboard').show();
	  }
	  
	  $(this).data("clicks", !clicks);

	});

	$(this).scrollTop(0);


	// Login

	$('.fixedicons .logon').click(function(){
		$(this).addClass('active');
		$('.logonmdb, .mdboverlay').show();
	});

	$('.closemdb').click(function(){
		$('.logonmdb').hide;
		$('.logonmdb, .mdboverlay').hide();
	});


	$('.logonform').on('submit', function(){
		$('.login-secondstep').show();
		$('.login-firststep').hide();
	});

	$('.loginback').click(function(){
		$('.login-secondstep').hide();
		$('.login-firststep').show();
	});

	//Only on dashboard page script should work
	if ($('#addevent').length > 0)
    {
		$('#addevent').datepicker({
			inline: true,
			altField: '#eventd1'
		});

		$('#eventd1').change(function(){
			$('#addevent').datepicker('setDate', $(this).val());
		});
	
		$( "#tabs" ).tabs();
	}

});

new WOW().init();

function collapse(id){
	$('#'+id).toggleClass("in");
}

$(function(){
	$(window).resize(function() {
	  //resize just happened, pixels changed
	  var win = $(this),
        w = win.width(),
        h = win.height();
        //alert(w);
        if(w<=1375)
        {
        	$(".fixedicons ul li").each(function () {        		
        		$(this).find('p').hide();
        		$(this).find('a').css('width','auto');
        	});        	
        }
        else
        {
       		$(".fixedicons ul li").each(function () {
        		$(this).find('p').show();        		
        	}); 
        }
	});
});