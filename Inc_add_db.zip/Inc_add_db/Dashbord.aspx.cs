﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using System.Data.SqlTypes;
using System.Data.Sql;
using System.Data.Odbc;
using System.Data.SqlTypes;

public partial class Dashbord : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       try{ 
           
       OdbcConnection conn = new OdbcConnection(@"C:\Users\19264\Documents\Visual Studio 2012\WebSites\Inc_add_db\App_Data\Database.sdf");
       OdbcCommand cmd = new OdbcCommand();
       cmd.CommandText = "SELECT * from Table1";      
       cmd.Connection = conn;
       conn.Open();
       Label1.Text="connected"; 
    }
       catch (Exception ex){
           Label1.Text=(ex.ToString());
          
        }

    }

   
    
    protected void Button1_Click(object sender, EventArgs e)
    {
       
       
        if(fileupload1.HasFile)
            // Call a helper method routine to save the file.
            SaveFile(fileupload1.PostedFile);
        else
            // Notify the user that a file was not uploaded.
            Label1.Text = "You did not specify a file to upload.";
    }
    void SaveFile(HttpPostedFile file)
    {
        // Specify the path to save the uploaded file to.
        string savePath = "c:\\Users\\19264\\Documents\\Visual Studio 2012\\WebSites\\Inc_add_db\\images";

        // Get the name of the file to upload.
        string fileName = "c:\\Users\\19264\\Documents\\Visual Studio 2012\\WebSites\\Inc_add_db\\images";

        // Create the path and file name to check for duplicates.
        string pathToCheck = savePath + fileName;

        // Create a temporary file name to use for checking duplicates.
        string tempfileName = "";

        // Check to see if a file already exists with the
        // same name as the file to upload.        
        if (System.IO.File.Exists(pathToCheck))
        {
            int counter = 2;
            while (System.IO.File.Exists(pathToCheck))
            {
                // if a file with this name already exists,
                // prefix the filename with a number.
                tempfileName = counter.ToString() + fileName;
                pathToCheck = savePath + tempfileName;
                counter++;
            }

            fileName = tempfileName;

            // Notify the user that the file name was changed.
            Label1.Text = "A file with the same name already exists." +
                "<br />Your file was saved as " + fileName;
        }
        else
        {
            // Notify the user that the file was saved successfully.
            Label1.Text = "Your file was uploaded successfully to " + savePath;
        }

        // Append the name of the file to upload to the path.
        savePath += fileName;

        // Call the SaveAs method to save the uploaded
        // file to the specified directory.
        fileupload1.SaveAs(Server.MapPath(fileupload1.FileName));

    }


 
}