﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Btn_Click(object sender, EventArgs e)
    {
        if((Tb_id.Text == "lalanjha") & (Tb_psw.Text == "lalanjha"))
        {
            Response.Redirect("Dashbord.aspx");
        }

        else
        {
       Response.Write("Wrong id password");
       Label1.Text=("Wrong id/password");
          
        }

    }
}