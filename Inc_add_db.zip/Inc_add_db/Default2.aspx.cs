﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;


public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DirectoryInfo dir;
        StringBuilder sb = new StringBuilder();
        FileInfo[] files;

        dir = new DirectoryInfo(Server.MapPath(".\\images"));
        files = dir.GetFiles();
        foreach (FileInfo f in files)
        {
            sb.Append("<a href=\"" + f.Name.ToString() + "\">");
            sb.Append(f.Name.ToString() + "</a><br />");
        }
     
        Literal1.Text = sb.ToString();

    }
}